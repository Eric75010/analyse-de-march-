# analyse-de-marche-
#P2 Utilitsez les bases de Python pour l'analyse de marché

#Aller sur le projet

https://github.com/Eric75010/analyse-de-marche.git

#Créer l'environnement virtuel

installez Python :
https://python.org/downloads/

#executer la fonction scrap:

all_categories.py

